a =11
print(type(a))
#
a =111.2
print(type(a))

#
a='sssssff'
print(type(a))

#
a="shjshs"
print(type(a))

#
a =True 
print(type(a))
#
a =[1111,22,33,44]
print(type(a))
print(a)
print(a[0])

print(max(a))
print(min(a))
print('sum of all values :', sum(a))

a[0] =333
print(a)

#
t = (111,2222,3333,4)
print(type(t))
print(t)
#t[0] =444


#
d ={'a':'alpha','t':'tata',1:'one'}
print(type(d))
print(d['t'])

#
s = {'dove','lux','dove'}
print(type(s))
print(s)




