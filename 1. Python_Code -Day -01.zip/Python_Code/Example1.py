a = 1
b = 4
c=a+b
print(c)

#
a,b =1,2
print(a+b)

#
a =b = 5
print(a)
print(b)

